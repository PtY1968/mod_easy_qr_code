<?php
/**
 *  @Copyright
 *
 *  @package	Easy QR-Code Module
 *  @author     Peter Szladovics
 *  @version	Version: 1.0 - 30-Jan-2014
 *  @link       Project Site {@link https://github.com/PtY1968/mod_easy_qr_code}
 *
 *  @license GNU/GPL
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
defined('_JEXEC') or die('Restricted access');

if(!defined('DS'))
{
    define('DS', DIRECTORY_SEPARATOR);
}

require_once (dirname(__FILE__).DS.'helper.php');

$MOD_EASY_QR_CODE_code = new mod_easy_qr_codeHelper;
$output = $MOD_EASY_QR_CODE_code->createOutput($params);

require(JModuleHelper::getLayoutPath('mod_easy_qr_code', 'default'));
